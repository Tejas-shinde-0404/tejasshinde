package com.example.codeforcesviewer.UserData.ContestData

data class ContestDataToShow(val number: String,
                             val name: String,
                             val rank: String,
                             val ratingChange: String,
                             val newRating: String,
                             val ratingChangeColor: Int,
                             val newRatingColor: Int)