package com.example.codeforcesviewer.UserData.UserInfo

data class UserPublicData(
        val result: List<Users>,
        val status: String
)