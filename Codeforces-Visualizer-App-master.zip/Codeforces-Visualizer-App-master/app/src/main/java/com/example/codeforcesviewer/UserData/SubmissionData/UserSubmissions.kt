package com.example.codeforcesviewer.UserData.SubmissionData

data class UserSubmissions(
        val result: List<Submission>,
        val status: String
)