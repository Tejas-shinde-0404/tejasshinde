package com.example.codeforcesviewer.UserData.ContestData

data class UserContests(
        val result: List<Contests>,
        val status: String
)