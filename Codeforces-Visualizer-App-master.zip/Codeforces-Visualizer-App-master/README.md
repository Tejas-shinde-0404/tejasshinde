# Codeforces-Visualizer-App
An android app that you can use to stalk anybody on Codeforces. Just enter the handle and you can get to know the User Information, Rating Graph, Rated Contest Details, Problems Solved by 'Difficulty' and 'Index' of that user.
